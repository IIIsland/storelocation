from sklearn.datasets import make_regression
from sklearn.ensemble import GradientBoostingRegressor
from sklearn.ensemble import AdaBoostRegressor
import pandas as pd
import math
from matplotlib import pyplot as plt
from sklearn import metrics
import numpy as np
from sklearn.metrics import mean_squared_error
from sklearn.model_selection import train_test_split
from sklearn.model_selection import GridSearchCV
from sklearn.tree import DecisionTreeRegressor
df=pd.read_excel('data.xlsx')
def get_dcg(y_pred, y_true,k):
 
    df = pd.DataFrame({"y_pred":y_pred, "y_true":y_true})
    df = df.sort_values(by="y_pred", ascending=False)  
    df = df.iloc[0:k, :]  
    dcg = df["y_true"] / np.log2(np.arange(1, df["y_true"].count()+1) + 1)  
    dcg = np.sum(dcg)
    return dcg
def get_ndcg(y_pred, y_true,k):
    dcg = get_dcg(y_pred, y_true,k)
    idcg = get_dcg(y_true, y_true,k)
    ndcg = dcg / idcg
    return ndcg

Y=df.iloc[:,0]
X=df.iloc[:,1:df.shape[1]]
AA=[]
BB=[]
CC=[]
for i in range(1,51):
    trainX, testX, trainY, testY = train_test_split(X, Y, test_size = 0.2,random_state = i)

    trainX1=pd.DataFrame(trainX)
    testX=pd.DataFrame(testX)
    trainX=((trainX-trainX.mean())/trainX.std())
    testX=(testX-trainX1.mean())/trainX1.std()

    max_depth=list(range(10,50,10))
    min_samples_split=list(range(10,50,10))

    knn=GradientBoostingRegressor(random_state=111)
    grid1 = GridSearchCV(estimator=knn,param_grid=dict(max_depth=max_depth,min_samples_split=min_samples_split),cv=5,scoring='neg_root_mean_squared_error')
    grid1.fit(trainX, trainY)
    max_depth=grid1.best_params_['max_depth']
    min_samples_split=grid1.best_params_['min_samples_split']
    reg=GradientBoostingRegressor(random_state=111,max_depth=max_depth,min_samples_split=min_samples_split)
    reg.fit(trainX, trainY)

    seq_predictions=reg.predict(testX)
    ndcg = get_ndcg(seq_predictions, testY, k = 30)
    mse=math.sqrt(metrics.mean_squared_error(testY,seq_predictions))
    mape=metrics.mean_absolute_percentage_error(testY,seq_predictions)
    AA.append(ndcg)
    BB.append(mse)
    CC.append(mape)

