from sklearn.datasets import make_regression
from sklearn.ensemble import GradientBoostingRegressor
from sklearn.ensemble import AdaBoostRegressor
import pandas as pd
import math
from matplotlib import pyplot as plt
from sklearn import metrics
import numpy as np
from sklearn.metrics import mean_squared_error
from sklearn.model_selection import train_test_split
from sklearn.model_selection import GridSearchCV
from sklearn.tree import DecisionTreeRegressor
from sklearn.linear_model import Lasso
def topK_loss_hit(testY,seq_predictions):

    testY1=pd.DataFrame(testY)
    seq_predictions1=pd.DataFrame({'y_pre':seq_predictions,'ind':testY1.index,'y_true':testY})
    B=seq_predictions1.sort_values(by='y_pre',ascending=False)
    testY1.columns=['t1']
    testY2=testY1.sort_values(by='t1',ascending=False)

    T=[]
    P=[]
    for K in [1, 5, 10 ,15 ,20 ,25 ,30,35,40,45,50,55,60,65,70,75,80,85,90,95,100,105,110,115,120,125,130,135,140,145]:
        p=0
        C=B['ind'][0:K]
        A=B['y_true'][0:K]
        D=testY2[0:K]
        for i in C:
            for j in range(K):
                if i==testY2.index[j]:
                    p=p+1
        P.append(p/K)
        E=np.average(A)
        F=np.average(D)
        G=(F-E)/F
        T.append(G)
    return T,P

print(topK_loss_hit(testY,seq_predictions)[0])
print(topK_loss_hit(testY,seq_predictions)[1])

