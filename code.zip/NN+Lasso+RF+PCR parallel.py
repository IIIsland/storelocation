from keras import models
from keras import layers
from keras.layers import Dense
from sklearn.metrics import r2_score
from matplotlib import pyplot as plt
from keras.wrappers.scikit_learn import KerasRegressor
from keras import regularizers
import math
from sklearn.linear_model import Lasso
from sklearn.ensemble import RandomForestRegressor
from sklearn.datasets import make_regression
from sklearn.ensemble import GradientBoostingRegressor
import pandas as pd
import warnings
from sklearn import metrics
from sklearn.model_selection import GridSearchCV
import numpy as np
from sklearn.metrics import mean_squared_error
from sklearn.model_selection import train_test_split
import tensorflow as tf
from sklearn.linear_model import LinearRegression
from sklearn.decomposition import PCA
from matplotlib import pyplot as plt
import heapq
df=pd.read_excel('data.xlsx')
def get_dcg(y_pred, y_true,k):
    df = pd.DataFrame({"y_pred":y_pred, "y_true":y_true})
    df = df.sort_values(by="y_pred", ascending=False)  
    df = df.iloc[0:k, :] 
    dcg = df["y_true"] / np.log2(np.arange(1, df["y_true"].count()+1) + 1) 
    dcg = np.sum(dcg)
    return dcg

def get_ndcg(y_pred, y_true,k):
    dcg = get_dcg(y_pred, y_true,k)
    idcg = get_dcg(y_true, y_true,k)
    ndcg = dcg / idcg
    return ndcg
Y=df.iloc[:,0]

X=df.iloc[:,1:df.shape[1]]
AA=[]
BB=[]
CC=[]

for i in range(1,51):
    warnings.filterwarnings('ignore')
    def create_model(neurons=1,activation='relu'):
        tf.random.set_seed(4)
        network = models.Sequential()
        network.add(layers.Dense(neurons, activation = activation, input_shape = (trainX.shape[1],), kernel_regularizer=regularizers.l2(0.001)))
        network.add(layers.Dense(neurons, activation = activation,kernel_regularizer=regularizers.l2(0.001)))
        network.add(layers.Dense( 1, activation = activation))
        network.compile( loss = 'mse' , metrics=['mse'])
        return network
    trainX, testX, trainY, testY = train_test_split(X, Y, test_size = 0.2,random_state = i)
    trainX1=pd.DataFrame(trainX)
    testX=pd.DataFrame(testX)
    trainX=((trainX-trainX.mean())/trainX.std())
    testX=(testX-trainX1.mean())/trainX1.std()

    k = [0.1,0.2,0.3,0.4,0.5 ,0.6,0.7,0.8,0.9,1,2,3,4,5,10,100]

    knn = Lasso()
    grid1 = GridSearchCV(estimator=knn, param_grid=dict(alpha=k),cv=5,scoring='neg_root_mean_squared_error',)
    grid1.fit(trainX, trainY)
    alpha=grid1.best_params_['alpha']
    #T=np.random.rand(594)
    regressor=Lasso(alpha=alpha)

    regressor.fit(trainX,trainY)

    neurons=list(range(40,100,5))
    activation = [ 'relu', 'linear']
    model=KerasRegressor(build_fn=create_model,verbose=0,epochs=200,batch_size=100)
    param_grid = dict(neurons=neurons,activation=activation)
    grid2 = GridSearchCV(estimator=model, param_grid=param_grid, cv=5 ,scoring='neg_root_mean_squared_error')
    grid2.fit(trainX, trainY)
    j=grid2.best_params_['neurons']
    activation=grid2.best_params_['activation']
    network = models.Sequential()
    network.add(layers.Dense(units = j, activation = activation, input_shape = (trainX.shape[1],), kernel_regularizer=regularizers.l2(0.001)))
    network.add(layers.Dense(units = j, activation = activation,kernel_regularizer=regularizers.l2(0.001)))
    network.add(layers.Dense(units = 1, activation = activation))

    network.compile( loss = 'mse', optimizer = 'rmsprop', metrics = ['mse'] )
    regressor1=network
    regressor1.fit(trainX,trainY,epochs = 200, verbose = 0, batch_size = 100)

    max_depth=list(range(10,50,10))
    min_samples_leaf=list(range(10,50,10))
    knn1=RandomForestRegressor(random_state=111)
    grid3 = GridSearchCV(estimator=knn1,param_grid=dict(max_depth=max_depth,min_samples_leaf=min_samples_leaf),cv=5,scoring='neg_root_mean_squared_error')
    grid3.fit(trainX, trainY)
    max_depth=grid3.best_params_['max_depth']
    min_samples_leaf=grid3.best_params_['min_samples_leaf']
    regressor2=RandomForestRegressor(max_depth=max_depth,min_samples_leaf=min_samples_leaf,random_state=111)
    regressor2.fit(trainX,trainY)

    seq_predictions1=regressor.predict(testX)
    seq_predictions2=regressor1.predict(testX)
    seq_predictions3=regressor2.predict(testX)

    pca = PCA(n_components='mle')
    pca.fit(trainX)
    trainX = pca.transform(trainX)
    testX=pca.transform(testX)
    regressor3=LinearRegression()

    regressor3.fit(trainX,trainY)
    seq_predictions4=regressor3.predict(testX)


    seq_predictions1=pd.DataFrame(seq_predictions1)
    seq_predictions2=pd.DataFrame(seq_predictions2)
    seq_predictions3=pd.DataFrame(seq_predictions3)
    seq_predictions4=pd.DataFrame(seq_predictions4)

    seq_predictions44=np.append(seq_predictions1,seq_predictions2,1)
    seq_predictions44=np.append(seq_predictions44,seq_predictions3,1)
    seq_predictions44=np.append(seq_predictions44,seq_predictions4,1)
    seq_predictions=np.average(seq_predictions44,axis=1)

    ndcg = get_ndcg(seq_predictions, testY, k = 30)
    mse=math.sqrt(metrics.mean_squared_error(testY,seq_predictions))
    mape=metrics.mean_absolute_percentage_error(testY,seq_predictions)
    AA.append(ndcg)
    BB.append(mse)
    CC.append(mape)

