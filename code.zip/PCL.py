from keras.models import load_model
from sklearn.linear_model import LinearRegression
from sklearn.decomposition import PCA
from sklearn.linear_model import Lasso
from sklearn.datasets import make_regression
from sklearn.ensemble import GradientBoostingRegressor
import pandas as pd
import warnings
import math
from sklearn import metrics
from sklearn.model_selection import GridSearchCV
import numpy as np
from sklearn.metrics import mean_squared_error
from sklearn.model_selection import train_test_split
import tensorflow as tf
from matplotlib import pyplot as plt
df=pd.read_excel('data.xlsx')
warnings.filterwarnings('ignore')
def get_dcg(y_pred, y_true,k):
    df = pd.DataFrame({"y_pred":y_pred, "y_true":y_true})
    df = df.sort_values(by="y_pred", ascending=False)  
    df = df.iloc[0:k, :]  
    dcg = df["y_true"] / np.log2(np.arange(1, df["y_true"].count()+1) + 1) 
    dcg = np.sum(dcg)
    return dcg

def get_ndcg(y_pred, y_true,k):
    dcg = get_dcg(y_pred, y_true,k)
    idcg = get_dcg(y_true, y_true,k)
    ndcg = dcg / idcg
    return ndcg

Y=df.iloc[:,0]


X=df.iloc[:,1:df.shape[1]]

AA=[]
BB=[]
CC=[]
for i in range(1,51):

    trainX, testX, trainY, testY = train_test_split(X, Y, test_size = 0.2,random_state = i)
    trainX1=pd.DataFrame(trainX)
    testX=pd.DataFrame(testX)
    trainX=((trainX-trainX.mean())/trainX.std())
    testX=(testX-trainX1.mean())/trainX1.std()
    pca = PCA(n_components='mle')
    pca.fit(trainX)
    trainX = pca.transform(trainX)
    testX=pca.transform(testX)
    regressor=LinearRegression()

    regressor.fit(trainX,trainY)
    seq_predictions=regressor.predict(testX)
    ndcg = get_ndcg(seq_predictions, testY, k = 30)
    mse=math.sqrt(metrics.mean_squared_error(testY,seq_predictions))
    mape=metrics.mean_absolute_percentage_error(testY,seq_predictions)
    AA.append(ndcg)
    BB.append(mse)
    CC.append(mape)

